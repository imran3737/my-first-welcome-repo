pub fn counter(start_val: i32, end_val: i32) {
    for count in start_val..end_val {
        println!("counter value is:{}", count);
    }
}
